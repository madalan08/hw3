from flask_wtf import FlaskForm
from wtforms import StringField, IntegerField, SubmitField
from wtforms import validators, StringField, SubmitField
class Add_form(FlaskForm):
    name = StringField("NAME")
    mark = StringField("GRADE:")
    submit = SubmitField("ADD")
class DelForm(FlaskForm):
     id = IntegerField("ID:")
     submit = SubmitField("DELETE")
class update_form(FlaskForm):
    id = IntegerField("ID:")
    name = StringField("NAME")
    mark = StringField("GRADE:")
    submit = SubmitField("UPDATE")

